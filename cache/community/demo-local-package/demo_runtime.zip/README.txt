This archive is a safe local package installer test payload.
