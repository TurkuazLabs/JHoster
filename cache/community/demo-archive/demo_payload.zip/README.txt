JHoster demo archive payload
This file was extracted by the safe zip extractor.
